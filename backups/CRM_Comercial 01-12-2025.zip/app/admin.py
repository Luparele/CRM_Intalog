from django.contrib import admin
from .models import (
    Profile, Cliente, Servico, TipoServico, Meta, 
    Tarefa, AcaoTarefa, Prospeccao, AcaoProspeccao
)

# Register your models here.

@admin.register(TipoServico)
class TipoServicoAdmin(admin.ModelAdmin):
    list_display = ('nome',)

@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    # Adicionamos 'filial' na listagem e no filtro
    list_display = ('razao_social', 'filial', 'cnpj', 'nome_contato', 'cadastrado_por')
    search_fields = ('razao_social', 'cnpj')
    list_filter = ('filial', 'cadastrado_por')

@admin.register(Servico)
class ServicoAdmin(admin.ModelAdmin):
    list_display = ('cliente', 'tipo_servico', 'data_servico', 'valor', 'fechado_por')
    search_fields = ('cliente__razao_social',)
    list_filter = ('data_servico', 'fechado_por', 'tipo_servico')

@admin.register(Meta)
class MetaAdmin(admin.ModelAdmin):
    # Removemos 'filial' direto da meta, mas podemos mostrar via cliente
    list_display = ('cliente', 'get_cliente_filial', 'mes', 'ano', 'valor', 'dias_uteis')
    list_filter = ('ano', 'mes', 'cliente__filial') # Filtra pela filial do cliente
    search_fields = ('cliente__razao_social',)
    
    # Método auxiliar para mostrar a filial na lista de metas
    @admin.display(ordering='cliente__filial', description='Filial')
    def get_cliente_filial(self, obj):
        return obj.cliente.get_filial_display()

class AcaoTarefaInline(admin.TabularInline):
    model = AcaoTarefa
    extra = 1
    readonly_fields = ('registrado_por', 'data_registro')
    fields = ('descricao', 'registrado_por', 'data_registro')

@admin.register(Tarefa)
class TarefaAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'status', 'criado_por', 'data_criacao', 'iniciado_por', 'finalizado_por')
    list_filter = ('status', 'criado_por', 'iniciado_por', 'finalizado_por')
    search_fields = ('titulo', 'descricao')
    readonly_fields = ('data_criacao', 'data_inicio', 'data_finalizacao')
    inlines = [AcaoTarefaInline]
    fieldsets = (
        (None, {'fields': ('titulo', 'descricao', 'status')}),
        ('Histórico', {
            'classes': ('collapse',),
            'fields': ('criado_por', 'data_criacao', 'iniciado_por', 'data_inicio', 'finalizado_por', 'data_finalizacao'),
        }),
    )

@admin.register(AcaoTarefa)
class AcaoTarefaAdmin(admin.ModelAdmin):
    list_display = ('tarefa', 'registrado_por', 'data_registro')
    list_filter = ('registrado_por', 'data_registro')
    search_fields = ('descricao', 'tarefa__titulo')

# --- INÍCIO DO NOVO CÓDIGO PARA PROSPECÇÃO ---

class AcaoProspeccaoInline(admin.TabularInline):
    """
    Permite visualizar e adicionar ações de prospecção diretamente na página de uma prospecção.
    """
    model = AcaoProspeccao
    extra = 0 # Não mostra campos extras para adicionar, pois as ações são registradas pelo sistema
    readonly_fields = ('descricao', 'registrado_por', 'data_registro')
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False

@admin.register(Prospeccao)
class ProspeccaoAdmin(admin.ModelAdmin):
    """
    Configuração da visualização das Prospecções no painel de administração.
    """
    list_display = ('cliente', 'status', 'valor_total', 'criado_por', 'data_criacao', 'finalizado_por')
    list_filter = ('status', 'tipo_proposta', 'criado_por', 'finalizado_por')
    search_fields = ('cliente__razao_social',)
    readonly_fields = ('data_criacao', 'data_inicio_negociacao', 'data_finalizacao')
    
    # Adiciona a visualização das ações dentro da página da prospecção
    inlines = [AcaoProspeccaoInline]
    
    fieldsets = (
        ('Informações Principais', {
            'fields': ('cliente', 'status', 'tipo_proposta', 'valor_total')
        }),
        ('Estimativas', {
            'fields': ('duracao_meses', 'viagens_aproximadas', 'valor_medio_viagem')
        }),
        ('Histórico', {
            'classes': ('collapse',),
            'fields': ('criado_por', 'data_criacao', 'iniciado_por', 'data_inicio_negociacao', 'finalizado_por', 'data_finalizacao'),
        }),
    )

@admin.register(AcaoProspeccao)
class AcaoProspeccaoAdmin(admin.ModelAdmin):
    """
    Configuração para visualização da lista de todas as ações de prospecção.
    """
    list_display = ('prospeccao', 'registrado_por', 'data_registro')
    list_filter = ('registrado_por', 'data_registro')
    search_fields = ('descricao', 'prospeccao__cliente__razao_social')

# --- FIM DO NOVO CÓDIGO ---