from django import forms
from django.contrib.auth.models import User
from .models import Profile, Cliente, ClienteProspect, Servico, Meta, Tarefa, AcaoTarefa, Prospeccao, AcaoProspeccao
from django.contrib.auth.forms import AuthenticationForm
from decimal import Decimal
import calendar
from datetime import date


class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'username', 'email')
        help_texts = {
            'username': None,
        }

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        # --- ALTERAÇÃO: Trocamos 'eh_representante' por 'setor' ---
        fields = ('telefone', 'setor', 'status')
        widgets = {
            'setor': forms.Select(attrs={'class': 'form-select'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }

class ClienteForm(forms.ModelForm):
    """ Formulário para Clientes ATIVOS (Com serviços) """
    class Meta:
        model = Cliente
        fields = ['cnpj', 'razao_social', 'filial', 'endereco', 'nome_contato', 'telefone_contato']
        
        widgets = {
            'filial': forms.Select(attrs={'class': 'form-select'}),
        }

class ClienteProspectForm(forms.ModelForm):
    """ Formulário para cadastro rápido de Prospects (Funil de Vendas) """
    class Meta:
        model = ClienteProspect
        fields = ['cnpj', 'razao_social', 'nome_contato', 'telefone_contato', 'email_contato']
        widgets = {
            'email_contato': forms.EmailInput(attrs={'placeholder': 'exemplo@email.com'}),
        }

class ServicoForm(forms.ModelForm):
    """
    Formulário para criar/editar um Serviço.
    """
    class Meta:
        model = Servico
        fields = ['cliente', 'tipo_servico', 'data_servico', 'quantidade', 'valor']
        
        widgets = {
            'data_servico': forms.DateInput(format='%Y-%m-%d', attrs={'type': 'date'}),
            'tipo_servico': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        # Serviços só podem ser lançados para clientes da tabela definitiva (Cliente)
        
        # --- ALTERAÇÃO DE REGRA: Financeiro vê tudo, Rep apenas o seu ---
        if user:
            # Se for admin ou Financeiro ou Comercial
            if user.is_staff or user.profile.setor in ['FINANCEIRO', 'COMERCIAL', 'ADMIN']:
                self.fields['cliente'].queryset = Cliente.objects.all().order_by('razao_social')
            else:
                # Se for Representante
                self.fields['cliente'].queryset = Cliente.objects.filter(cadastrado_por=user).order_by('razao_social')

class MetaForm(forms.ModelForm):
    class Meta:
        model = Meta
        fields = ['cliente', 'mes', 'ano', 'dias_uteis', 'valor']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['cliente'].queryset = Cliente.objects.order_by('razao_social')

class CustomAuthenticationForm(AuthenticationForm):
    def confirm_login_allowed(self, user):
        super().confirm_login_allowed(user)
        if hasattr(user, 'profile') and user.profile.status == 'INATIVO':
            raise forms.ValidationError(
                "Usuário INATIVO! Por favor, entre em contato com o administrador para solicitar a reativação.",
                code='inactive_profile'
            )

class TarefaForm(forms.ModelForm):
    class Meta:
        model = Tarefa
        fields = ['titulo', 'descricao']
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 4}),
        }

class AcaoTarefaForm(forms.ModelForm):
    class Meta:
        model = AcaoTarefa
        fields = ['descricao', 'arquivo']
        labels = {
            'descricao': "Ação a ser Tomada:",
            'arquivo': "Anexar Arquivo (Opcional):"
        }
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Descreva a ação realizada ou o próximo passo...'}),
            'arquivo': forms.FileInput(attrs={'class': 'form-control form-control-sm'})
        }

# --- Campos Personalizados ---

class ProspectChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return f"{obj.razao_social} ({obj.cnpj or 'S/ CNPJ'})"

class ProspeccaoForm(forms.ModelForm):
    cliente = ProspectChoiceField(
        queryset=ClienteProspect.objects.none(),
        label="Prospect"
    )

    class Meta:
        model = Prospeccao
        fields = [
            'cliente', 'tipo_proposta', 'duracao_meses', 
            'viagens_aproximadas', 'valor_medio_viagem'
        ]

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        prospects_queryset = ClienteProspect.objects.order_by('razao_social')

        # Lógica de filtro de Prospeccao: 
        # Representante só vê os dele. Comercial/Admin vê tudo. Financeiro não acessa (bloqueado na view)
        if user:
            if user.is_staff or user.profile.setor in ['COMERCIAL', 'ADMIN']:
                self.fields['cliente'].queryset = prospects_queryset
            else:
                self.fields['cliente'].queryset = prospects_queryset.filter(cadastrado_por=user)

    def clean(self):
        cleaned_data = super().clean()
        viagens = cleaned_data.get('viagens_aproximadas')
        valor_medio = cleaned_data.get('valor_medio_viagem')

        if viagens and valor_medio:
            cleaned_data['valor_total'] = Decimal(viagens) * valor_medio
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.valor_total = self.cleaned_data.get('valor_total', 0)
        if commit:
            instance.save()
        return instance

class AcaoProspeccaoForm(forms.ModelForm):
    class Meta:
        model = AcaoProspeccao
        fields = ['descricao', 'arquivo']
        labels = {
            'descricao': "Ação a ser Tomada:",
            'arquivo': "Anexar Arquivo (Opcional):"
        }
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Descreva a ação realizada ou o próximo passo...'}),
            'arquivo': forms.FileInput(attrs={'class': 'form-control form-control-sm'})
        }

class ProspeccaoEditForm(forms.ModelForm):
    """ Formulário para editar os detalhes de uma prospecção existente. """
    class Meta:
        model = Prospeccao
        fields = [
            'tipo_proposta', 'duracao_meses', 
            'viagens_aproximadas', 'valor_medio_viagem'
        ]

    def clean(self):
        cleaned_data = super().clean()
        viagens = cleaned_data.get('viagens_aproximadas')
        valor_medio = cleaned_data.get('valor_medio_viagem')

        if viagens and valor_medio:
            cleaned_data['valor_total'] = Decimal(viagens) * valor_medio
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.valor_total = self.cleaned_data.get('valor_total', instance.valor_total)
        if commit:
            instance.save()
        return instance