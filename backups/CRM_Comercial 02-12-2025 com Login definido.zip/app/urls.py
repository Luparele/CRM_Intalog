from django.urls import path
from . import views

app_name = 'app'

urlpatterns = [
    # URL da Home (página principal que carrega a estrutura)
    path('', views.home_page, name='home'),

    # --- URLs PARA OS BLOCOS DO DASHBOARD (HTMX) ---
    path('dash/mensal/', views.get_dashboard_mensal, name='get-dash-mensal'),
    path('dash/trimestral/', views.get_dashboard_trimestral, name='get-dash-trimestral'),
    path('dash/anual/', views.get_dashboard_anual, name='get-dash-anual'),
    path('dash/top-clientes/', views.get_dashboard_top_clientes, name='get-dash-top-clientes'),
    
    # URLs para gerenciamento de Representantes (Usuários)
    path('representantes/', views.RepresentanteListView.as_view(), name='representante-list'),
    path('representantes/novo/', views.RepresentanteCreateView.as_view(), name='representante-create'),
    path('representantes/<int:pk>/editar/', views.RepresentanteUpdateView.as_view(), name='representante-update'),
    path('representantes/<int:pk>/detalhe/', views.detalhe_representante, name='detalhe-representante'),

    # URLs para gerenciamento de Clientes
    path('clientes/', views.ClienteListView.as_view(), name='cliente-list'),
    path('clientes/novo/', views.ClienteCreateView.as_view(), name='cliente-create'),
    path('clientes/<int:pk>/', views.ClienteDetailView.as_view(), name='cliente-detail'),
    path('clientes/<int:pk>/editar/', views.ClienteUpdateView.as_view(), name='cliente-update'),
    path('clientes/<int:pk>/deletar/', views.ClienteDeleteView.as_view(), name='cliente-delete'),
    
    # --- ROTAS DE PROMOÇÃO DE PROSPECT (MIGRAÇÃO ASSISTIDA) ---
    path('prospects/<int:pk>/promover/', views.promover_prospect_modal, name='promover-prospect-modal'),
    path('prospects/<int:pk>/salvar-promocao/', views.salvar_promocao_prospect, name='salvar-promocao-prospect'),

    # URLs para gerenciamento de Serviços
    path('servicos/', views.ServicoListView.as_view(), name='servico-list'),
    path('servicos/novo/', views.ServicoCreateView.as_view(), name='servico-create'),
    path('servicos/<int:pk>/editar/', views.ServicoUpdateView.as_view(), name='servico-update'),
    path('servicos/<int:pk>/deletar/', views.ServicoDeleteView.as_view(), name='servico-delete'),
    path('servicos/historico/<int:cliente_id>/<int:mes>/<int:ano>/', views.servico_historico_modal, name='servico-historico-modal'),
    path('servicos/<int:pk>/editar-modal/', views.editar_servico_modal, name='servico-update-modal'),
    
    # URLs para gerenciamento de Metas
    path('metas/', views.MetaListView.as_view(), name='meta-list'),
    path('metas/nova/', views.MetaCreateView.as_view(), name='meta-create'),
    path('metas/<int:pk>/editar/', views.MetaUpdateView.as_view(), name='meta-update'),
    path('metas/<int:pk>/deletar/', views.MetaDeleteView.as_view(), name='meta-delete'),

    # URLs da Agenda
    path('agenda/', views.agenda_page, name='agenda'),
    path('agenda/tarefa/nova/', views.criar_tarefa, name='criar-tarefa'),
    path('agenda/tarefa/<int:pk>/detalhe/', views.detalhe_tarefa, name='detalhe-tarefa'),
    path('agenda/tarefa/<int:pk>/iniciar/', views.iniciar_tarefa, name='iniciar-tarefa'),
    path('agenda/tarefa/<int:pk>/gravar_acao/', views.gravar_acao, name='gravar-acao'),
    path('agenda/tarefa/<int:pk>/finalizar/', views.finalizar_tarefa, name='finalizar-tarefa'),
    path('agenda/carregar-mais/', views.carregar_mais_tarefas, name='carregar-mais-tarefas'),
    path('agenda/header-count/<str:status>/', views.get_agenda_header_count, name='get-agenda-header-count'),

    # URLs da Prospecção
    path('prospeccao/', views.prospeccao_page, name='prospeccao'),
    path('prospeccao/nova/', views.criar_prospeccao, name='criar-prospeccao'),
    path('prospeccao/<int:pk>/detalhe/', views.detalhe_prospeccao, name='detalhe-prospeccao'),
    path('prospeccao/<int:pk>/iniciar/', views.iniciar_prospeccao, name='iniciar-prospeccao'),
    path('prospeccao/<int:pk>/editar/', views.editar_prospeccao, name='editar-prospeccao'),
    path('prospeccao/<int:pk>/gravar_acao/', views.gravar_acao_prospeccao, name='gravar-acao-prospeccao'),
    path('prospeccao/<int:pk>/finalizar/', views.finalizar_prospeccao, name='finalizar-prospeccao'),
    path('prospeccao/novo-cliente/', views.criar_cliente_prospeccao_modal, name='criar-cliente-prospeccao-modal'),
    path('prospeccao/salvar-cliente/', views.salvar_cliente_prospeccao, name='salvar-cliente-prospeccao'),

    # URLs de Relatórios
    path('relatorios/', views.relatorio_page, name='relatorio-page'),
    path('relatorios/exportar/', views.exportar_relatorio, name='exportar-relatorio'),

    # URL de Direitos
    path('direitos/', views.direitos_page, name='direitos'),

    # Dashboard de Prospecção (REATIVADO)
    path('dashboard-prospeccao/', views.dashboard_prospeccao_page, name='dashboard-prospeccao'),

    # URLs de API
    path('api/consulta-cnpj/<str:cnpj>/', views.consulta_cnpj, name='consulta-cnpj'),
    path('api/tipo-servico/novo/', views.add_tipo_servico, name='add-tipo-servico'),
    path('api/search-clientes/', views.cliente_search_api, name='cliente-search-api'),
]