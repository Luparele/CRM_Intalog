from django import forms
from django.contrib.auth.models import User
from .models import Profile, Cliente, Servico, Meta, Tarefa, AcaoTarefa, Prospeccao, AcaoProspeccao
from django.contrib.auth.forms import AuthenticationForm
from decimal import Decimal
import calendar
from datetime import date


class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'username', 'email')
        help_texts = {
            'username': None,
        }

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ('telefone', 'eh_representante', 'status')
        widgets = {
            'eh_representante': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['cnpj', 'razao_social', 'filial', 'endereco', 'nome_contato', 'telefone_contato']
        
        widgets = {
            'filial': forms.Select(attrs={'class': 'form-select'}),
        }

class ServicoForm(forms.ModelForm):
    """
    Formulário para criar/editar um Serviço.
    """
    class Meta:
        model = Servico
        fields = ['cliente', 'tipo_servico', 'data_servico', 'quantidade', 'valor']
        
        widgets = {
            # --- CORREÇÃO AQUI: Adicionado format='%Y-%m-%d' ---
            # Isso força o Django a renderizar a data no formato ISO (AAAA-MM-DD),
            # que é o único formato aceito pelo <input type="date"> do HTML5 para pré-preenchimento.
            'data_servico': forms.DateInput(format='%Y-%m-%d', attrs={'type': 'date'}),
            'tipo_servico': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user and not user.is_staff:
            self.fields['cliente'].queryset = Cliente.objects.filter(cadastrado_por=user)

class MetaForm(forms.ModelForm):
    class Meta:
        model = Meta
        fields = ['cliente', 'mes', 'ano', 'dias_uteis', 'valor']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['cliente'].queryset = Cliente.objects.order_by('razao_social')

class CustomAuthenticationForm(AuthenticationForm):
    def confirm_login_allowed(self, user):
        super().confirm_login_allowed(user)
        if hasattr(user, 'profile') and user.profile.status == 'INATIVO':
            raise forms.ValidationError(
                "Usuário INATIVO! Por favor, entre em contato com o administrador para solicitar a reativação.",
                code='inactive_profile'
            )

class TarefaForm(forms.ModelForm):
    class Meta:
        model = Tarefa
        fields = ['titulo', 'descricao']
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 4}),
        }

class AcaoTarefaForm(forms.ModelForm):
    class Meta:
        model = AcaoTarefa
        fields = ['descricao', 'arquivo']
        labels = {
            'descricao': "Ação a ser Tomada:",
            'arquivo': "Anexar Arquivo (Opcional):"
        }
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Descreva a ação realizada ou o próximo passo...'}),
            'arquivo': forms.FileInput(attrs={'class': 'form-control form-control-sm'})
        }

# --- Campos Personalizados ---

class ClienteChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return f"{obj.razao_social} ({obj.cnpj})"

class ProspeccaoForm(forms.ModelForm):
    cliente = ClienteChoiceField(
        queryset=Cliente.objects.none(),
        label="Cliente"
    )

    class Meta:
        model = Prospeccao
        fields = [
            'cliente', 'tipo_proposta', 'duracao_meses', 
            'viagens_aproximadas', 'valor_medio_viagem'
        ]

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        clientes_queryset = Cliente.objects.order_by('razao_social')

        if user and not user.is_staff:
            self.fields['cliente'].queryset = clientes_queryset.filter(cadastrado_por=user)
        else:
            self.fields['cliente'].queryset = clientes_queryset

    def clean(self):
        cleaned_data = super().clean()
        viagens = cleaned_data.get('viagens_aproximadas')
        valor_medio = cleaned_data.get('valor_medio_viagem')

        if viagens and valor_medio:
            cleaned_data['valor_total'] = Decimal(viagens) * valor_medio
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.valor_total = self.cleaned_data.get('valor_total', 0)
        if commit:
            instance.save()
        return instance

class AcaoProspeccaoForm(forms.ModelForm):
    class Meta:
        model = AcaoProspeccao
        fields = ['descricao', 'arquivo']
        labels = {
            'descricao': "Ação a ser Tomada:",
            'arquivo': "Anexar Arquivo (Opcional):"
        }
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Descreva a ação realizada ou o próximo passo...'}),
            'arquivo': forms.FileInput(attrs={'class': 'form-control form-control-sm'})
        }

class ProspeccaoEditForm(forms.ModelForm):
    """ Formulário para editar os detalhes de uma prospecção existente. """
    class Meta:
        model = Prospeccao
        fields = [
            'tipo_proposta', 'duracao_meses', 
            'viagens_aproximadas', 'valor_medio_viagem'
        ]

    def clean(self):
        cleaned_data = super().clean()
        viagens = cleaned_data.get('viagens_aproximadas')
        valor_medio = cleaned_data.get('valor_medio_viagem')

        if viagens and valor_medio:
            cleaned_data['valor_total'] = Decimal(viagens) * valor_medio
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.valor_total = self.cleaned_data.get('valor_total', instance.valor_total)
        if commit:
            instance.save()
        return instance