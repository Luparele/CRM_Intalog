import sqlite3

# Conecta ao banco de dados
conn = sqlite3.connect('db.sqlite3')
cursor = conn.cursor()

try:
    print("Limpando tabela de Ações de Prospecção...")
    cursor.execute("DELETE FROM app_acaoprospeccao")
    
    print("Limpando tabela de Prospecções...")
    cursor.execute("DELETE FROM app_prospeccao")
    
    conn.commit()
    print("Sucesso! Dados de prospecção limpos.")
    print("Agora você pode rodar o makemigrations e migrate novamente.")

except Exception as e:
    print(f"Erro ao limpar banco: {e}")

finally:
    conn.close()