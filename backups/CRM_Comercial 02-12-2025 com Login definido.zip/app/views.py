from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy, reverse
from django.views.generic import ListView, CreateView, UpdateView, DetailView, DeleteView, TemplateView
from django.contrib.auth.models import User
from django.contrib.auth import login 
from django.db.models import Q, Avg
from django.http import HttpResponse, JsonResponse
from django.template.loader import render_to_string
from dateutil.relativedelta import relativedelta
from collections import defaultdict 
from io import BytesIO
from xhtml2pdf import pisa
import pandas as pd
from .models import Profile, Cliente, ClienteProspect, Servico, TipoServico, Meta, Tarefa, AcaoTarefa, Prospeccao, AcaoProspeccao
from .forms import UserForm, ProfileForm, ServicoForm, MetaForm, CustomAuthenticationForm, TarefaForm, AcaoTarefaForm, ProspeccaoForm, AcaoProspeccaoForm, ClienteForm, ProspeccaoEditForm, ClienteProspectForm
from django.db import transaction
from django.db.models import Sum, Count,Avg, F, DurationField
from django.utils import timezone
import calendar
import requests
from decimal import Decimal
from datetime import date
import json
import time

# Certifique-se de que este Mixin está definido no início do arquivo (antes das Views)
class ComercialAdminRequiredMixin(UserPassesTestMixin):
    """ Permite acesso apenas para Comercial e Admin (Staff ou Setor Admin) """
    def test_func(self):
        u = self.request.user
        # Verifica se está logado, ativo e se é Staff ou do setor Comercial/Admin
        # (A propriedade .tem_acesso_gestao foi definida no models.py)
        return u.is_authenticated and u.is_active and (u.is_staff or u.profile.tem_acesso_gestao)

class ComercialAdminRequiredMixin(UserPassesTestMixin):
    """ Permite acesso apenas para Comercial e Admin (Staff ou Setor Admin) """
    def test_func(self):
        u = self.request.user
        return u.is_active and (u.is_staff or u.profile.tem_acesso_gestao)

class FinanceiroRequiredMixin(UserPassesTestMixin):
    """ Permite acesso apenas ao Financeiro (e Staff para manutenção) """
    def test_func(self):
        u = self.request.user
        return u.is_active and (u.is_staff or u.profile.is_financeiro)

class ClienteEditorMixin(UserPassesTestMixin):
    """ 
    Regra para Editar/Excluir Clientes:
    - Financeiro: NÃO PODE.
    - Comercial/Admin: PODE TUDO.
    - Representante: PODE (apenas os seus).
    """
    def test_func(self):
        user = self.request.user
        if user.profile.is_financeiro:
            return False 
        if user.is_staff or user.profile.tem_acesso_gestao:
            return True 
        # Se for Rep, verifica se é dono do registro
        obj = self.get_object()
        return obj.cadastrado_por == user

class ClienteCriadorMixin(UserPassesTestMixin):
    """ Financeiro não cria clientes. """
    def test_func(self):
        return not self.request.user.profile.is_financeiro

# --- VIEWS DOS DASHBOARDS ---

@login_required
def home_page(request):
    """
    View principal que renderiza a ESTRUTURA do dashboard.
    O conteúdo é carregado via HTMX.
    """
    # Se for Staff, Comercial ou Financeiro, vê o dashboard Admin. Se for Rep, vê o dashboard Representante.
    is_gestor = request.user.is_staff or request.user.profile.tem_acesso_gestao or request.user.profile.is_financeiro
    template_name = 'app/dashboard_admin.html' if is_gestor else 'app/dashboard_representante.html'
    return render(request, template_name)

def _get_filter_context(request):
    """
    Função auxiliar para gerar o contexto dos formulários de filtro
    lendo os parâmetros GET da requisição.
    """
    now = timezone.now()
    
    # Busca no banco todas as datas de serviços, agrupando por ano.
    datas_dos_servicos = Servico.objects.dates('data_servico', 'year')
    anos_com_servicos = [data.year for data in datas_dos_servicos]
    
    # Cria um conjunto (set) para evitar anos duplicados
    anos_set = set(anos_com_servicos)
    
    # Garante que o ano atual e o próximo sempre estejam na lista
    anos_set.add(now.year)
    anos_set.add(now.year + 1)
    
    # Transforma o conjunto em uma lista e a ordena em ordem decrescente
    anos_disponiveis_ordenados = sorted(list(anos_set), reverse=True)

    ano_mensal_str = request.GET.get('ano_mensal', str(now.year))
    ano_trimestral_str = request.GET.get('ano_trimestral', str(now.year))
    ano_anual_str = request.GET.get('ano_anual', str(now.year))
    
    context = {
        'anos_disponiveis': [str(ano) for ano in anos_disponiveis_ordenados],
        'meses_disponiveis': [(i, calendar.month_name[i].capitalize()) for i in range(1, 13)],
        'trimestres_disponiveis': [(1, '1º Trim.'), (2, '2º Trim.'), (3, '3º Trim.'), (4, '4º Trim.')],
        
        'ano_mensal_selecionado': int(ano_mensal_str.replace('.', '')),
        'mes_mensal_selecionado': int(request.GET.get('mes_mensal', now.month)),
        'ano_trimestral_selecionado': int(ano_trimestral_str.replace('.', '')),
        'trimestre_trimestral_selecionado': int(request.GET.get('trimestre_trimestral', (now.month - 1) // 3 + 1)),
        'ano_anual_selecionado': int(ano_anual_str.replace('.', '')),
    }
    return context

@login_required
def get_dashboard_mensal(request):
    context = _get_filter_context(request)
    ano_selecionado = context['ano_mensal_selecionado']
    mes_selecionado = context['mes_mensal_selecionado']

    base_services = Servico.objects.all()
    user = request.user
    
    # 1. Regra de Dashboard: Representante vê só o seu
    if user.profile.is_representante:
        base_services = base_services.filter(cliente__cadastrado_por=user)
    # Financeiro, Comercial, Admin veem TUDO (não filtra)
        
    services_this_month = base_services.filter(data_servico__year=ano_selecionado, data_servico__month=mes_selecionado)
    
    faturamento_mensal = services_this_month.aggregate(total=Sum('valor'))['total'] or 0
    total_viagens_mes = services_this_month.aggregate(total=Sum('quantidade'))['total'] or 0

    now = timezone.now()
    _, ultimo_dia_mes = calendar.monthrange(ano_selecionado, mes_selecionado)
    dias_restantes = ultimo_dia_mes - now.date().day if ano_selecionado == now.year and mes_selecionado == now.month else 0
    dias_restantes = max(0, dias_restantes)

    context.update({
        'mensal_faturamento': faturamento_mensal,
        'mensal_servicos_fechados': total_viagens_mes, 
        'mensal_nome_mes': calendar.month_name[mes_selecionado].capitalize(),
        'mensal_dias_restantes': dias_restantes,
    })

    # CÁLCULO DE META MENSAL
    meta_queryset = Meta.objects.filter(ano=ano_selecionado, mes=mes_selecionado)
    faturamento_a_considerar = faturamento_mensal

    if user.profile.is_representante:
        meta_queryset = meta_queryset.filter(cliente__cadastrado_por=user)
    
    valor_meta_total = meta_queryset.aggregate(total=Sum('valor'))['total'] or Decimal('0.00')
    
    context['mensal_meta'] = {'valor': valor_meta_total} if valor_meta_total > 0 else None

    if valor_meta_total > 0:
        percentual = (faturamento_a_considerar / valor_meta_total) * 100
        context['mensal_percentual_meta'] = percentual
        context['mensal_faturamento_faltante'] = max(Decimal('0.00'), valor_meta_total - faturamento_a_considerar)
    
    # Desempenho Clientes (Ranking)
    desempenho_clientes = services_this_month.values('cliente__razao_social') \
        .annotate(
            total_valor=Sum('valor'),
            total_viagens=Sum('quantidade')
        ).order_by('-total_valor')
    
    context['desempenho_clientes'] = desempenho_clientes

    # Desempenho da Equipe (Apenas para Gestores)
    if not user.profile.is_representante:
        representantes_performance = []
        # Filtra apenas usuários marcados como representantes
        representantes_ativos = User.objects.filter(profile__setor='REPRESENTANTE', profile__status='ATIVO')
        
        for rep in representantes_ativos:
            faturamento_rep = Servico.objects.filter(
                cliente__cadastrado_por=rep, 
                data_servico__year=ano_selecionado, 
                data_servico__month=mes_selecionado
            ).aggregate(total=Sum('valor'))['total'] or 0
            
            meta_rep_valor = Meta.objects.filter(cliente__cadastrado_por=rep, ano=ano_selecionado, mes=mes_selecionado).aggregate(total=Sum('valor'))['total'] or 0
            
            percentual_individual = (faturamento_rep / meta_rep_valor) * 100 if meta_rep_valor > 0 else 0
            
            representantes_performance.append({ 
                'nome': rep.first_name, 
                'faturamento': faturamento_rep, 
                'percentual_individual': percentual_individual,
            })
        context['representantes_performance'] = representantes_performance

    return render(request, 'app/partials/_dashboard_mensal.html', context)

@login_required
def dashboard_prospeccao_page(request):
    # 3. Regra de Prospecção: Financeiro NÃO ACESSA
    if request.user.profile.is_financeiro:
        return HttpResponse("Acesso Negado ao Financeiro", status=403)

    context = {}
    data_inicial = request.GET.get('data_inicial')
    data_final = request.GET.get('data_final')
    representante_id = request.GET.get('representante_id')

    base_queryset = Prospeccao.objects.select_related('cliente', 'criado_por')

    # Comercial/Admin vê todos, Rep vê só o seu
    if request.user.profile.is_representante:
        base_queryset = base_queryset.filter(criado_por=request.user)
    else:
        context['representantes'] = User.objects.filter(profile__setor='REPRESENTANTE', is_active=True).order_by('username')
        if representante_id and representante_id != 'todos':
            base_queryset = base_queryset.filter(criado_por_id=representante_id)

    kpi_queryset = base_queryset
    if data_inicial:
        kpi_queryset = kpi_queryset.filter(data_finalizacao__gte=data_inicial)
    if data_final:
        kpi_queryset = kpi_queryset.filter(data_finalizacao__lte=data_final)

    prospeccoes_finalizadas = kpi_queryset.filter(status__in=['FECHADO', 'DESISTENCIA', 'PERDIDA'])
    prospeccoes_fechadas = prospeccoes_finalizadas.filter(status='FECHADO')

    total_finalizadas = prospeccoes_finalizadas.count()
    total_fechadas = prospeccoes_fechadas.count()
    context['taxa_conversao'] = (total_fechadas / total_finalizadas * 100) if total_finalizadas > 0 else 0
    context['total_fechado_valor'] = prospeccoes_fechadas.aggregate(total=Sum('valor_total'))['total'] or Decimal('0.00')
    context['ticket_medio'] = prospeccoes_fechadas.aggregate(media=Avg('valor_total'))['media'] or Decimal('0.00')
    
    tempo_negociacao = kpi_queryset.exclude(data_inicio_negociacao__isnull=True).annotate(
        tempo=F('data_finalizacao') - F('data_inicio_negociacao')
    ).aggregate(media_tempo=Avg('tempo'))['media_tempo']
    context['tempo_medio_dias'] = tempo_negociacao.days if tempo_negociacao else 0

    funil_data = kpi_queryset.values('status').annotate(count=Count('status')).order_by('status')
    context['funil_labels'] = [item['status'].replace('_', ' ').title() for item in funil_data]
    context['funil_counts'] = [item['count'] for item in funil_data]
    
    if not request.user.profile.is_representante:
        performance_data = prospeccoes_fechadas.values('criado_por__username') \
            .annotate(total_valor=Sum('valor_total')).order_by('-total_valor')
        context['performance_labels'] = [item['criado_por__username'] for item in performance_data]
        context['performance_valores'] = [float(item['total_valor']) for item in performance_data]
        
    previsao_faturamento = defaultdict(Decimal)
    hoje = timezone.now().date()
    for p in base_queryset.filter(status='FECHADO'):
        if p.duracao_meses > 0 and p.data_finalizacao:
            valor_mensal = p.valor_total / p.duracao_meses
            data_inicio_projecao = p.data_finalizacao.date()
            for i in range(p.duracao_meses):
                mes_projecao = data_inicio_projecao + relativedelta(months=i)
                if mes_projecao.year > hoje.year or (mes_projecao.year == hoje.year and mes_projecao.month >= hoje.month):
                    previsao_faturamento[mes_projecao.strftime('%Y-%m')] += valor_mensal

    context['previsao_faturamento'] = [{'mes_ano': timezone.datetime.strptime(k, '%Y-%m').strftime('%B/%Y').capitalize(), 'valor': v} for k, v in sorted(previsao_faturamento.items())]

    # --- ALTERAÇÃO AQUI: Renderiza o PARTIAL, não a página inteira ---
    return render(request, 'app/partials/_dashboard_prospeccao_content.html', context)

@login_required
def get_dashboard_trimestral(request):
    context = _get_filter_context(request)
    ano_selecionado = context['ano_trimestral_selecionado']
    trimestre_selecionado = context['trimestre_trimestral_selecionado']

    base_services = Servico.objects.all()
    base_clients = Cliente.objects.all()
    if request.user.profile.is_representante:
        # Filtra por cliente cadastrado pelo usuário
        base_services = base_services.filter(cliente__cadastrado_por=request.user)
        base_clients = base_clients.filter(cadastrado_por=request.user)

    start_month = (trimestre_selecionado - 1) * 3 + 1
    end_month = start_month + 2
    services_this_quarter = base_services.filter(data_servico__year=ano_selecionado, data_servico__month__gte=start_month, data_servico__month__lte=end_month)

    context.update({
        'trimestral_faturamento': services_this_quarter.aggregate(total=Sum('valor'))['total'] or 0,
        'trimestral_nome': f'{trimestre_selecionado}º Trimestre',
    })

    faturamento_por_tipo = services_this_quarter.values('tipo_servico__nome').annotate(total=Sum('valor')).order_by('-total')
    context['trimestral_pizza_labels'] = [item['tipo_servico__nome'] for item in faturamento_por_tipo]
    context['trimestral_pizza_data'] = [float(item['total']) for item in faturamento_por_tipo]

    bar_labels, faturamento_data, clientes_data = [], [], []
    for month_num in range(start_month, end_month + 1):
        bar_labels.append(calendar.month_abbr[month_num].capitalize())
        faturamento = base_services.filter(data_servico__year=ano_selecionado, data_servico__month=month_num).aggregate(total=Sum('valor'))['total'] or 0
        faturamento_data.append(float(faturamento))
        
        # Conta clientes ATIVOS novos
        novos_clientes = Cliente.objects.filter(data_cadastro__year=ano_selecionado, data_cadastro__month=month_num)
        if request.user.profile.is_representante:
            novos_clientes = novos_clientes.filter(cadastrado_por=request.user)
        clientes_data.append(novos_clientes.count())
        
    context['trimestral_bar_labels'] = bar_labels
    context['trimestral_faturamento_data'] = faturamento_data
    context['trimestral_clientes_data'] = clientes_data

    return render(request, 'app/partials/_dashboard_trimestral.html', context)

@login_required
def get_dashboard_anual(request):
    context = _get_filter_context(request)
    ano_selecionado = context['ano_anual_selecionado']

    base_services = Servico.objects.all()
    base_clients = Cliente.objects.all()
    
    if request.user.profile.is_representante:
        # Filtra por cliente cadastrado pelo usuário
        base_services = base_services.filter(cliente__cadastrado_por=request.user)
        base_clients = base_clients.filter(cadastrado_por=request.user)
    
    services_this_year = base_services.filter(data_servico__year=ano_selecionado)
    context['anual_faturamento'] = services_this_year.aggregate(total=Sum('valor'))['total'] or 0
    
    faturamento_por_tipo = services_this_year.values('tipo_servico__nome').annotate(total=Sum('valor')).order_by('-total')
    context['anual_pizza_labels'] = [item['tipo_servico__nome'] for item in faturamento_por_tipo]
    context['anual_pizza_data'] = [float(item['total']) for item in faturamento_por_tipo]
    
    bar_labels, faturamento_data, clientes_data, historico_metas = [], [], [], []
    for i in range(12):
        month = 12 - i
        mes_nome = calendar.month_abbr[month].capitalize()
        bar_labels.insert(0, mes_nome)
        faturamento = base_services.filter(data_servico__year=ano_selecionado, data_servico__month=month).aggregate(total=Sum('valor'))['total'] or 0
        faturamento_data.insert(0, float(faturamento))
        
        novos_clientes = Cliente.objects.filter(data_cadastro__year=ano_selecionado, data_cadastro__month=month)
        if request.user.profile.is_representante:
            novos_clientes = novos_clientes.filter(cadastrado_por=request.user)
        clientes_data.insert(0, novos_clientes.count())
        
        meta_query = Meta.objects.filter(ano=ano_selecionado, mes=month)
        if request.user.profile.is_representante:
            meta_query = meta_query.filter(cliente__cadastrado_por=request.user)
            
        valor_meta = meta_query.aggregate(total=Sum('valor'))['total'] or 0
        
        status_meta = "Sem Meta"
        if valor_meta > 0:
            if faturamento >= valor_meta: status_meta = "Atingida"
            else: status_meta = "Não Atingida"
        else:
            valor_meta = None 

        historico_metas.append({ 'mes_ano': mes_nome, 'faturamento': faturamento, 'meta': valor_meta, 'status': status_meta })

    context['anual_bar_labels'] = bar_labels
    context['anual_faturamento_data'] = faturamento_data
    context['anual_clientes_data'] = clientes_data
    context['historico_metas_anual'] = historico_metas

    return render(request, 'app/partials/_dashboard_anual.html', context)

@login_required
def get_dashboard_top_clientes(request):
    now = timezone.now()
    
    base_services = Servico.objects.all()
    if request.user.profile.is_representante:
        # Filtra por cliente cadastrado pelo usuário
        base_services = base_services.filter(cliente__cadastrado_por=request.user)

    services_this_month = base_services.filter(data_servico__year=now.year, data_servico__month=now.month)
    clientes_do_mes_annotated = services_this_month.values('cliente__razao_social') \
        .annotate(
            faturamento_total=Sum('valor'),
            # Soma a quantidade em vez de contar
            num_servicos=Sum('quantidade')
        )
    top_clientes_mensal_faturamento = clientes_do_mes_annotated.order_by('-faturamento_total')[:5]
    top_clientes_mensal_servicos = clientes_do_mes_annotated.order_by('-num_servicos')[:5]

    current_quarter = (now.month - 1) // 3 + 1
    start_month = (current_quarter - 1) * 3 + 1
    end_month = start_month + 2
    services_this_quarter = base_services.filter(data_servico__year=now.year, data_servico__month__gte=start_month, data_servico__month__lte=end_month)
    clientes_do_trimestre_annotated = services_this_quarter.values('cliente__razao_social') \
        .annotate(
            faturamento_total=Sum('valor'),
            # Soma a quantidade em vez de contar
            num_servicos=Sum('quantidade')
        )
    top_clientes_trimestral_faturamento = clientes_do_trimestre_annotated.order_by('-faturamento_total')[:5]
    top_clientes_trimestral_servicos = clientes_do_trimestre_annotated.order_by('-num_servicos')[:5]

    services_this_year = base_services.filter(data_servico__year=now.year)
    clientes_do_ano_annotated = services_this_year.values('cliente__razao_social') \
        .annotate(
            faturamento_total=Sum('valor'),
            # Soma a quantidade em vez de contar
            num_servicos=Sum('quantidade')
        )
    top_clientes_anual_faturamento = clientes_do_ano_annotated.order_by('-faturamento_total')[:5]
    top_clientes_anual_servicos = clientes_do_ano_annotated.order_by('-num_servicos')[:5]

    context = {
        'top_clientes_mensal_faturamento': top_clientes_mensal_faturamento,
        'top_clientes_mensal_servicos': top_clientes_mensal_servicos,
        'top_clientes_trimestral_faturamento': top_clientes_trimestral_faturamento,
        'top_clientes_trimestral_servicos': top_clientes_trimestral_servicos,
        'top_clientes_anual_faturamento': top_clientes_anual_faturamento,
        'top_clientes_anual_servicos': top_clientes_anual_servicos,
    }
    
    return render(request, 'app/partials/_dashboard_top_clientes.html', context)
# --- FIM DO DASHBOARD ---

# --- RESTANTE DAS VIEWS (CRUDs, APIs, etc) ---

@login_required
def detalhe_representante(request, pk):
    representante = get_object_or_404(User, pk=pk)
    user_logado = request.user
    
    # 6. Representantes: Rep vê só o seu perfil. Outros veem todos.
    if user_logado.profile.is_representante and user_logado != representante:
        return HttpResponse("Acesso Negado", status=403)

    hoje = date.today()

    # Filtra serviços pelos clientes do representante, não por quem fechou
    servicos = Servico.objects.filter(cliente__cadastrado_por=representante)
    
    # Cálculo do Ticket Médio por QUANTIDADE de Viagens
    agregados = servicos.aggregate(total_valor=Sum('valor'), total_qtd=Sum('quantidade'))
    total_valor_historico = agregados['total_valor'] or Decimal('0.00')
    total_qtd_historico = agregados['total_qtd'] or 0
    
    if total_qtd_historico > 0:
        ticket_medio = total_valor_historico / total_qtd_historico
    else:
        ticket_medio = Decimal('0.00')

    vendas_mes_atual = servicos.filter(data_servico__year=hoje.year, data_servico__month=hoje.month)
    total_vendas_valor = vendas_mes_atual.aggregate(total=Sum('valor'))['total'] or Decimal('0.00')
    
    # Soma a quantidade de viagens em vez de contar registros
    total_vendas_qtd = vendas_mes_atual.aggregate(total=Sum('quantidade'))['total'] or 0
    
    meta_queryset = Meta.objects.filter(
        cliente__cadastrado_por=representante, 
        ano=hoje.year, 
        mes=hoje.month
    )
    total_meta_valor = meta_queryset.aggregate(total=Sum('valor'))['total'] or Decimal('0.00')
    
    meta_mes_atual = {'valor': total_meta_valor} if total_meta_valor > 0 else None

    prospeccoes = Prospeccao.objects.filter(criado_por=representante)
    prospeccoes_pendentes = prospeccoes.filter(status__in=['NOVA', 'NEGOCIANDO']).count()
    finalizadas_hist = prospeccoes.filter(status__in=['FECHADO', 'DESISTENCIA', 'PERDIDA'])
    fechadas_hist = finalizadas_hist.filter(status='FECHADO')
    taxa_conversao_hist = (fechadas_hist.count() / finalizadas_hist.count() * 100) if finalizadas_hist.count() > 0 else 0
    finalizadas_mes = finalizadas_hist.filter(data_finalizacao__year=hoje.year, data_finalizacao__month=hoje.month)
    fechadas_mes = finalizadas_mes.filter(status='FECHADO')
    taxa_conversao_mes = (fechadas_mes.count() / finalizadas_mes.count() * 100) if finalizadas_mes.count() > 0 else 0
    tempo_negociacao = finalizadas_hist.exclude(data_inicio_negociacao__isnull=True).annotate(
        tempo=F('data_finalizacao') - F('data_inicio_negociacao')
    ).aggregate(
        media_tempo=Avg('tempo', output_field=DurationField())
    )['media_tempo']
    media_dias_negociacao = tempo_negociacao.days if tempo_negociacao else 0

    context = {
        'rep': representante,
        # Conta apenas clientes ATIVOS na carteira (tabela Cliente)
        'clientes_count': Cliente.objects.filter(cadastrado_por=representante).count(),
        'ticket_medio': ticket_medio,
        'total_vendas_valor_mes': total_vendas_valor,
        'total_vendas_qtd_mes': total_vendas_qtd,
        'meta_mes_atual': meta_mes_atual,
        'prospeccoes_pendentes': prospeccoes_pendentes,
        'taxa_conversao_hist': taxa_conversao_hist,
        'taxa_conversao_mes': taxa_conversao_mes,
        'media_dias_negociacao': media_dias_negociacao,
    }
    
    return render(request, 'app/partials/_detalhe_representante_modal.html', context)

class RepresentanteListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = User
    template_name = 'app/representante_list.html'
    context_object_name = 'representantes'
    
    # --- REGRA DE SEGURANÇA: Bloqueia Financeiro ---
    def test_func(self):
        # Retorna False (Acesso Negado) se for Financeiro
        return not self.request.user.profile.is_financeiro

    def get_queryset(self):
        # 6. Rep vê só o seu. Comercial/Admin vê todos.
        if self.request.user.profile.is_representante:
            return User.objects.filter(pk=self.request.user.pk).select_related('profile')
        return User.objects.filter(is_active=True).select_related('profile').order_by('username')

# 8. Cadastro de usuários: Restrito ao Comercial e Admin
class RepresentanteCreateView(LoginRequiredMixin, ComercialAdminRequiredMixin, CreateView):
    template_name = 'app/representante_form.html'
    form_class = UserForm
    success_url = reverse_lazy('app:representante-list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['profile_form'] = ProfileForm(self.request.POST)
        else:
            context['profile_form'] = ProfileForm()
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        profile_form = context['profile_form']
        
        if form.is_valid() and profile_form.is_valid():
            with transaction.atomic():
                user = form.save(commit=False)
                user.set_password('mudarsenha')
                user.save()
                
                profile = user.profile 
                profile.telefone = profile_form.cleaned_data['telefone']
                profile.setor = profile_form.cleaned_data['setor']
                # Lógica legada
                profile.eh_representante = (profile.setor == 'REPRESENTANTE')
                profile.status = profile_form.cleaned_data['status']
                profile.save()
                
            return redirect(self.success_url)
        else:
            return self.render_to_response(self.get_context_data(form=form))

class RepresentanteUpdateView(LoginRequiredMixin, ComercialAdminRequiredMixin, UpdateView):
    model = User
    form_class = UserForm
    template_name = 'app/representante_form.html'
    success_url = reverse_lazy('app:representante-list')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['profile_form'] = ProfileForm(self.request.POST, instance=self.object.profile)
        else:
            context['profile_form'] = ProfileForm(instance=self.object.profile)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        profile_form = context['profile_form']
        if form.is_valid() and profile_form.is_valid():
            with transaction.atomic():
                form.save()
                profile = profile_form.save(commit=False)
                # Garante a compatibilidade do campo booleano antigo
                profile.eh_representante = (profile.setor == 'REPRESENTANTE')
                profile.save()
            return redirect(self.success_url)
        return self.render_to_response(context)
# --- VIEWS DE CLIENTES ---

class ClienteListView(LoginRequiredMixin, ListView):
    model = Cliente
    template_name = 'app/cliente_list.html'
    context_object_name = 'clientes'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # --- Lógica para Clientes Prospects (Funil) ---
        search_query = self.request.GET.get('q')
        representante_filtro = self.request.GET.get('representante')
        
        # 5. Clientes: Rep vê os seus. Financeiro/Comercial/Admin vê todos.
        if self.request.user.profile.is_representante:
            prospects = ClienteProspect.objects.filter(cadastrado_por=self.request.user)
        else:
            prospects = ClienteProspect.objects.all()
            
        # Filtros para Prospects (mesma lógica dos clientes)
        if not self.request.user.profile.is_representante and representante_filtro:
            if representante_filtro == 'admin':
                prospects = prospects.filter(cadastrado_por=self.request.user)
            else:
                prospects = prospects.filter(cadastrado_por_id=representante_filtro)

        if search_query:
            prospects = prospects.filter(
                Q(razao_social__icontains=search_query) | 
                Q(cnpj__icontains=search_query)
            )
        
        context['prospects'] = prospects.order_by('razao_social')
        
        context['search_query'] = self.request.GET.get('q', '')
        context['selected_rep'] = self.request.GET.get('representante', '')
        
        # Filtro dropdown
        if not self.request.user.profile.is_representante:
            context['representantes_list'] = User.objects.filter(profile__setor='REPRESENTANTE').order_by('username')
        return context

    def get_queryset(self):
        # --- Lógica para Clientes Ativos (Tabela Definitiva) ---
        search_query = self.request.GET.get('q')
        representante_filtro = self.request.GET.get('representante')

        # 5. Clientes: Rep vê os seus. Financeiro/Comercial/Admin vê todos.
        if self.request.user.profile.is_representante:
            queryset = Cliente.objects.filter(cadastrado_por=self.request.user)
        else:
            queryset = Cliente.objects.all()

        if not self.request.user.profile.is_representante and representante_filtro:
            if representante_filtro == 'admin':
                queryset = queryset.filter(cadastrado_por=self.request.user)
            else:
                queryset = queryset.filter(cadastrado_por_id=representante_filtro)
        
        if search_query:
            queryset = queryset.filter(
                Q(razao_social__icontains=search_query) | 
                Q(cnpj__icontains=search_query)
            )
            
        return queryset.select_related('cadastrado_por').order_by('razao_social')

class ClienteDetailView(LoginRequiredMixin, DetailView):
    model = Cliente
    template_name = 'app/cliente_detail.html'
    context_object_name = 'cliente'

# 5. Clientes: Agora TODOS podem adicionar (Financeiro liberado)
class ClienteCreateView(LoginRequiredMixin, CreateView):
    model = Cliente
    template_name = 'app/cliente_form.html'
    fields = ['cnpj', 'razao_social', 'filial', 'endereco', 'nome_contato', 'telefone_contato']
    widgets = { 'filial': lambda: forms.Select(attrs={'class': 'form-select'}) }

    def form_valid(self, form):
        form.instance.cadastrado_por = self.request.user
        return super().form_valid(form)
    def get_success_url(self):
        return reverse('app:cliente-list')

# 5. Clientes: Edição restrita (Financeiro não, Rep só seu, Comercial/Admin tudo)
class ClienteUpdateView(LoginRequiredMixin, ClienteEditorMixin, UpdateView):
    model = Cliente
    template_name = 'app/cliente_form.html'
    fields = ['cnpj', 'razao_social', 'filial', 'endereco', 'nome_contato', 'telefone_contato']
    def get_success_url(self):
        return reverse('app:cliente-list')

class ClienteDeleteView(LoginRequiredMixin, ClienteEditorMixin, DeleteView):
    model = Cliente
    template_name = 'app/cliente_confirm_delete.html'
    success_url = reverse_lazy('app:cliente-list')

# --- VIEWS DE SERVIÇOS (TOTALMENTE MODIFICADA) ---

class ServicoListView(LoginRequiredMixin, TemplateView):
    """
    View modificada para funcionar como um Painel de Metas e Produção por Filial.
    """
    template_name = 'app/servico_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        hoje = date.today()
        
        # DEBUG: Mostra no terminal o que o filtro está recebendo
        print(f"DEBUG FILTRO SERVICOS: {self.request.GET}")

        # 1. Tratamento do MÊS (Independente)
        mes_get = self.request.GET.get('mes')
        try:
            mes = int(mes_get) if mes_get else hoje.month
        except (ValueError, TypeError):
            mes = hoje.month

        # 2. Tratamento do ANO (Independente)
        ano_get = self.request.GET.get('ano')
        try:
            ano = int(ano_get) if ano_get else hoje.year
        except (ValueError, TypeError):
            ano = hoje.year
            
        # Envia para o template como INTEIROS
        context['mes_selecionado'] = mes
        context['ano_selecionado'] = ano
        
        # Listas para os Dropdowns
        context['meses_disponiveis'] = [(i, calendar.month_name[i].capitalize()) for i in range(1, 13)]
        context['anos_disponiveis'] = list(range(hoje.year - 2, hoje.year + 3))

        # 2. Buscar Clientes
        clientes = Cliente.objects.all().order_by('razao_social')
        if self.request.user.profile.is_representante:
            # Filtra apenas clientes do representante logado
            clientes = clientes.filter(cadastrado_por=self.request.user)
            
        dados_por_filial = {
            'MATRIZ_SP': [],
            'FILIAL_PB': [],
            'FILIAL_GO': []
        }
        
        # 3. Otimização: Buscar dados em lote (Metas e Serviços) do período SELECIONADO
        metas = Meta.objects.filter(mes=mes, ano=ano)
        metas_map = {m.cliente_id: m for m in metas}
        
        servicos = Servico.objects.filter(data_servico__year=ano, data_servico__month=mes)
        if self.request.user.profile.is_representante:
             servicos = servicos.filter(cliente__cadastrado_por=self.request.user)
        
        # Alerta se não houver lançamentos
        context['sem_lancamentos'] = not servicos.exists()
             
        servicos_map = defaultdict(list)
        for s in servicos:
            servicos_map[s.cliente_id].append(s)
            
        # 4. Processamento dos cálculos
        for cliente in clientes:
            meta = metas_map.get(cliente.id)
            servicos_cliente = servicos_map.get(cliente.id, [])
            total_viagens = sum(s.quantidade for s in servicos_cliente)
            faturamento_bruto = sum(s.valor for s in servicos_cliente)
            
            valor_meta = meta.valor if meta else Decimal('0.00')
            dias_uteis = meta.dias_uteis if meta else 0
            
            percentual_atingido = 0
            if valor_meta > 0:
                percentual_atingido = (faturamento_bruto / valor_meta) * 100
            
            valor_faltante = max(Decimal('0.00'), valor_meta - faturamento_bruto)
            
            percentual_faltante = 0
            if percentual_atingido < 100:
                percentual_faltante = 100 - percentual_atingido

            meta_diaria = 0
            if dias_uteis > 0:
                meta_diaria = valor_meta / dias_uteis
                
            dados_cliente = {
                'cliente': cliente,
                'meta': meta,
                'tem_meta': meta is not None,
                'total_viagens': total_viagens,
                'faturamento_bruto': faturamento_bruto,
                'percentual_atingido': percentual_atingido,
                'valor_faltante': valor_faltante,
                'percentual_faltante': percentual_faltante,
                'meta_diaria': meta_diaria,
                'dias_uteis_meta': dias_uteis,
            }
            
            # Agrupa por filial
            filial_key = cliente.filial if cliente.filial in dados_por_filial else 'MATRIZ_SP'
            dados_por_filial[filial_key].append(dados_cliente)

        context['dados_por_filial'] = dados_por_filial
        return context

@login_required
def editar_servico_modal(request, pk):
    """
    View para editar um serviço existente via Modal (HTMX).
    """
    servico = get_object_or_404(Servico, pk=pk)

    # 4. Transportes: Somente Financeiro edita. Rep não pode.
    if not (request.user.profile.is_financeiro or request.user.is_staff):
        return HttpResponse(status=403)

    if request.method == 'POST':
        # Passa o usuário para o form filtrar os clientes corretamente
        form = ServicoForm(request.POST, instance=servico, user=request.user)
        if form.is_valid():
            form.save()
            # Retorna sinal para atualizar a página (recalcular dashboard)
            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    else:
        form = ServicoForm(instance=servico, user=request.user)
    
    return render(request, 'app/partials/_servico_form_modal.html', {'form': form, 'servico': servico})

# 4. Transportes: Somente Financeiro cria
class ServicoCreateView(LoginRequiredMixin, FinanceiroRequiredMixin, CreateView):
    model = Servico
    form_class = ServicoForm
    template_name = 'app/servico_form.html'
    success_url = reverse_lazy('app:servico-list')
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs
    def form_valid(self, form):
        form.instance.fechado_por = self.request.user
        return super().form_valid(form)

class ServicoUpdateView(LoginRequiredMixin, FinanceiroRequiredMixin, UpdateView):
    model = Servico
    form_class = ServicoForm
    template_name = 'app/servico_form.html'
    success_url = reverse_lazy('app:servico-list')
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

class ServicoDeleteView(LoginRequiredMixin, FinanceiroRequiredMixin, DeleteView):
    model = Servico
    template_name = 'app/servico_confirm_delete.html'
    success_url = reverse_lazy('app:servico-list')

# --- VIEWS DE METAS ---

class MetaListView(LoginRequiredMixin, ListView):
    model = Meta
    template_name = 'app/meta_list.html'
    context_object_name = 'metas'

    def get_queryset(self):
        # 7. Metas: Rep vê só as suas. Outros veem todas.
        try:
            year_str = self.request.GET.get('year', str(date.today().year))
            self.selected_year = int(year_str.replace('.', ''))
        except (ValueError, TypeError):
            self.selected_year = date.today().year

        queryset = Meta.objects.filter(ano=self.selected_year)
        if self.request.user.profile.is_representante:
            queryset = queryset.filter(cliente__cadastrado_por=self.request.user)
            
        return queryset.order_by('-mes', 'cliente__razao_social')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        anos_com_metas = Meta.objects.values_list('ano', flat=True).distinct().order_by('-ano')
        context['anos_disponiveis'] = list(anos_com_metas)
        if self.selected_year not in context['anos_disponiveis']:
             context['anos_disponiveis'].insert(0, self.selected_year)
        context['selected_year'] = self.selected_year
        return context

# 7. Metas: Só Financeiro define/modifica. Rep vê mas não toca.
class MetaCreateView(LoginRequiredMixin, FinanceiroRequiredMixin, CreateView):
    model = Meta
    form_class = MetaForm
    template_name = 'app/meta_form.html'
    success_url = reverse_lazy('app:meta-list')

class MetaUpdateView(LoginRequiredMixin, FinanceiroRequiredMixin, UpdateView):
    model = Meta
    form_class = MetaForm
    template_name = 'app/meta_form.html'
    success_url = reverse_lazy('app:meta-list')

class MetaDeleteView(LoginRequiredMixin, FinanceiroRequiredMixin, DeleteView):
    model = Meta
    template_name = 'app/meta_confirm_delete.html'
    success_url = reverse_lazy('app:meta-list')

# --- VIEWS DE APIs E OUTROS ---
@login_required
def consulta_cnpj(request, cnpj):
    cnpj = ''.join(filter(str.isdigit, cnpj))
    if len(cnpj) != 14:
        return JsonResponse({'error': 'CNPJ deve ter 14 dígitos.'}, status=400)
    
    url = f"https://brasilapi.com.br/api/cnpj/v1/{cnpj}"
    
    # Tentativa com Retries manuais para lidar com a instabilidade da BrasilAPI
    max_tentativas = 20 
    
    for tentativa in range(1, max_tentativas + 1):
        try:
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                endereco = f"{data.get('logradouro', '')}, {data.get('numero', '')} - {data.get('bairro', '')}, {data.get('municipio', '')}/{data.get('uf', '')}"
                return JsonResponse({'razao_social': data.get('razao_social', ''), 'endereco': endereco})
            
            if tentativa < max_tentativas:
                time.sleep(1) 
                continue

        except requests.RequestException:
            if tentativa < max_tentativas:
                time.sleep(1)
                continue
            return JsonResponse({'error': 'Erro de comunicação com a API.'}, status=500)

    return JsonResponse({'error': 'CNPJ não encontrado ou API instável após várias tentativas.'}, status=404)

@login_required
def add_tipo_servico(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            nome_servico = data.get('nome')
            if nome_servico:
                novo_servico, created = TipoServico.objects.get_or_create(nome=nome_servico)
                return JsonResponse({'id': novo_servico.id, 'nome': novo_servico.nome}, status=201)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Dados inválidos'}, status=400)
    return JsonResponse({'error': 'Método não permitido'}, status=405)

def custom_login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('app:home')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

@login_required
def relatorio_page(request):
    report_type = request.GET.get('report_type')
    context = {
        'report_type': report_type,
        'representantes': None,
        'resultados': None,
        'cliente_selecionado': None,
        'total_faturamento': 0,
        'total_servicos': 0,
        'total_clientes': 0,
    }

    if not request.user.profile.is_representante:
        context['representantes'] = User.objects.filter(profile__eh_representante=True).order_by('username')
    
    # Filtros comuns a todos os relatórios
    qs_servicos = Servico.objects.all()
    qs_clientes = Cliente.objects.all()
    
    if request.user.profile.is_representante:
        qs_servicos = qs_servicos.filter(cliente__cadastrado_por=request.user)
        qs_clientes = qs_clientes.filter(cadastrado_por=request.user)
    else:
        rep_id = request.GET.get('representante_id')
        if rep_id and rep_id != 'todos':
            qs_servicos = qs_servicos.filter(cliente__cadastrado_por_id=rep_id)
            qs_clientes = qs_clientes.filter(cadastrado_por_id=rep_id)

    if report_type == 'faturamento_periodo':
        data_inicial = request.GET.get('data_inicial')
        data_final = request.GET.get('data_final')
        
        if data_inicial:
            qs_servicos = qs_servicos.filter(data_servico__gte=data_inicial)
        if data_final:
            qs_servicos = qs_servicos.filter(data_servico__lte=data_final)
        
        resultados = qs_servicos.values('cliente__razao_social') \
            .annotate(
                faturamento_total=Sum('valor'),
                num_servicos=Count('id')
            ).order_by('-faturamento_total')
        
        context['resultados'] = resultados
        if resultados:
            context['total_faturamento'] = resultados.aggregate(total=Sum('faturamento_total'))['total'] or 0
            context['total_servicos'] = resultados.aggregate(total=Sum('num_servicos'))['total'] or 0

    elif report_type == 'clientes_cadastrados':
        context['resultados'] = qs_clientes.order_by('razao_social')
        context['total_clientes'] = qs_clientes.count()

    elif report_type == 'historico_cliente':
        cliente_id = request.GET.get('cliente_id')
        if cliente_id:
            try:
                cliente_selecionado = Cliente.objects.get(pk=cliente_id)
                context['cliente_selecionado'] = cliente_selecionado

                # Reaplica o filtro no qs_servicos que já está filtrado por permissão
                resultados = qs_servicos.filter(cliente=cliente_selecionado).order_by('-data_servico')

                context['resultados'] = resultados
                if resultados:
                    context['total_faturamento'] = resultados.aggregate(total=Sum('valor'))['total'] or 0
                    context['total_servicos'] = resultados.count()

            except Cliente.DoesNotExist:
                context['resultados'] = [] 
    
    if request.headers.get('HX-Request') == 'true':
        template_name = 'app/partials/_relatorio_resultados.html'
    else:
        template_name = 'app/relatorios.html'
        
    return render(request, template_name, context)

@login_required
def cliente_search_api(request):
    query = request.GET.get('q')
    if query:
        clientes = Cliente.objects.all()
        if request.user.profile.is_representante:
            clientes = clientes.filter(cadastrado_por=request.user)
        clientes = clientes.filter(razao_social__icontains=query)
        resultados = [{'id': cliente.id, 'text': f"{cliente.razao_social} ({cliente.cnpj})"} for cliente in clientes[:10]] 
        return JsonResponse(resultados, safe=False)
    return JsonResponse([], safe=False)

def render_to_pdf(template_src, context_dict={}):
    html = render_to_string(template_src, context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None

@login_required
def exportar_relatorio(request):
    # Reutiliza a lógica de relatorio_page para não duplicar código
    # (Idealmente refatoraríamos para um service/utils, mas aqui simplificamos)
    return redirect('app:relatorio-page') 

# --- INÍCIO DAS TAREFAS ---

@login_required
def agenda_page(request):
    # 2. Agenda: Financeiro não acessa
    if request.user.profile.is_financeiro:
         return HttpResponse("Acesso Negado ao Financeiro", status=403)

    base_queryset = Tarefa.objects.select_related('criado_por', 'iniciado_por', 'finalizado_por')
    filtro_selecionado = request.GET.get('representante_filtro', 'todos')
    
    # Comercial/Admin vê todos, Rep vê só o seu
    if not request.user.profile.is_representante:
        if filtro_selecionado == 'minhas':
            base_queryset = base_queryset.filter(criado_por=request.user)
        elif filtro_selecionado != 'todos':
            base_queryset = base_queryset.filter(criado_por_id=filtro_selecionado)
    else:
        base_queryset = base_queryset.filter(criado_por=request.user)

    sort_ni = request.GET.get('sort_ni', 'desc')
    sort_i = request.GET.get('sort_i', 'desc')
    sort_f = request.GET.get('sort_f', 'desc')

    sort_ni_prefix = '' if sort_ni == 'asc' else '-'
    sort_i_prefix = '' if sort_i == 'asc' else '-'
    sort_f_prefix = '' if sort_f == 'asc' else '-'

    total_finalizadas = base_queryset.filter(status='FINALIZADA').count()
    
    context = {
        'nao_iniciadas': base_queryset.filter(status='NAO_INICIADA').order_by(f'{sort_ni_prefix}data_criacao'),
        'iniciadas': base_queryset.filter(status='INICIADA').order_by(f'{sort_i_prefix}data_inicio'),
        'finalizadas': base_queryset.filter(status='FINALIZADA').order_by(f'{sort_f_prefix}data_finalizacao')[:10],
        'tem_mais_finalizadas': total_finalizadas > 10,
        'proxima_pagina': 2,
        'representantes': None,
        'filtro_selecionado': filtro_selecionado,
        'sort_ni_current': sort_ni,
        'sort_ni_next': 'desc' if sort_ni == 'asc' else 'asc',
        'sort_i_current': sort_i,
        'sort_i_next': 'desc' if sort_i == 'asc' else 'asc',
        'sort_f_current': sort_f,
        'sort_f_next': 'desc' if sort_f == 'asc' else 'asc',
    }
    
    if not request.user.profile.is_representante:
        context['representantes'] = User.objects.filter(profile__eh_representante=True).order_by('username')
        
    return render(request, 'app/agenda.html', context)

@login_required
def carregar_mais_tarefas(request):
    page = int(request.GET.get('page', '2'))
    per_page = 10
    offset = (page - 1) * per_page
    limit = offset + per_page
    
    base_queryset = Tarefa.objects.select_related('criado_por', 'finalizado_por')
    
    filtro_selecionado = request.GET.get('representante_filtro', 'todos')
    
    if request.user.is_staff:
        if filtro_selecionado == 'minhas':
            base_queryset = base_queryset.filter(criado_por=request.user)
        elif filtro_selecionado != 'todos':
            base_queryset = base_queryset.filter(criado_por_id=filtro_selecionado)
    else:
        base_queryset = base_queryset.filter(criado_por=request.user)

    tarefas_finalizadas = base_queryset.filter(status='FINALIZADA').order_by('-data_finalizacao')
    
    tarefas_para_mostrar = tarefas_finalizadas[offset:limit]
    
    tem_mais_finalizadas = tarefas_finalizadas.count() > limit
    
    context = {
        'finalizadas_paginadas': tarefas_para_mostrar,
        'tem_mais_finalizadas': tem_mais_finalizadas,
        'proxima_pagina': page + 1,
        'filtro_selecionado': filtro_selecionado,
    }

    return render(request, 'app/partials/_tarefas_finalizadas_paginadas.html', context)

@login_required
def criar_tarefa(request):
    if request.method == 'POST':
        form = TarefaForm(request.POST)
        if form.is_valid():
            tarefa = form.save(commit=False)
            tarefa.criado_por = request.user
            tarefa.save()
            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    else:
        form = TarefaForm()
    return render(request, 'app/partials/_tarefa_form_modal.html', {'form': form})

@login_required
def detalhe_tarefa(request, pk):
    tarefa = get_object_or_404(Tarefa, pk=pk)
    if request.user.profile.is_representante and tarefa.criado_por != request.user:
        return HttpResponse(status=403)
        
    context = {
        'tarefa': tarefa,
        'acao_form': AcaoTarefaForm()
    }
    return render(request, 'app/partials/_detalhe_tarefa_modal.html', context)

@login_required
def iniciar_tarefa(request, pk):
    tarefa = get_object_or_404(Tarefa, pk=pk)
    if request.method == 'POST':
        tarefa.status = 'INICIADA'
        tarefa.iniciado_por = request.user
        tarefa.data_inicio = timezone.now()
        tarefa.save()

        return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
        
    return HttpResponse(status=405)

@login_required
def get_agenda_header_count(request, status):
    base_queryset = Tarefa.objects.all()
    filtro_selecionado = request.GET.get('representante_filtro', 'todos')

    if not request.user.profile.is_representante:
        if filtro_selecionado == 'minhas':
            base_queryset = base_queryset.filter(criado_por=request.user)
        elif filtro_selecionado != 'todos':
            base_queryset = base_queryset.filter(criado_por_id=filtro_selecionado)
    else:
        base_queryset = base_queryset.filter(criado_por=request.user)
    
    count = base_queryset.filter(status=status.upper()).count()
    
    titles = {
        'NAO_INICIADA': 'Tarefas não Iniciadas',
        'INICIADA': 'Tarefas Iniciadas',
        'FINALIZADA': 'Tarefas Finalizadas',
    }
    context = {'title': titles.get(status.upper()), 'count': count, 'status': status}
    return render(request, 'app/partials/_agenda_header.html', context)

@login_required
def gravar_acao(request, pk):
    tarefa = get_object_or_404(Tarefa, pk=pk)
    if request.method == 'POST':
        print(f"DEBUG TAREFA - FILES: {request.FILES}") 
        
        form = AcaoTarefaForm(request.POST, request.FILES) 
        if form.is_valid():
            acao = form.save(commit=False)
            acao.tarefa = tarefa
            acao.registrado_por = request.user
            acao.save()
            response = render(request, 'app/partials/_acoes_list.html', {'tarefa': tarefa})
            response['HX-Trigger'] = 'updateCounters'
            return response
        else:
            print(f"DEBUG TAREFA - ERROS: {form.errors}")
            
    return HttpResponse(status=400)

@login_required
def finalizar_tarefa(request, pk):
    tarefa = get_object_or_404(Tarefa, pk=pk)
    if request.method == 'POST':
        tarefa.status = 'FINALIZADA'
        tarefa.finalizado_por = request.user
        tarefa.data_finalizacao = timezone.now()
        tarefa.save()
        
        return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
        
    return HttpResponse(status=405)

# --- FIM DAS TAREFAS ---

# --- VIEWS DE PÁGINAS DIREITOS E PROPRIEDADE ---
@login_required
def direitos_page(request):
    return render(request, 'app/direitos.html')

@login_required
def prospeccao_page(request):
    # 3. Prospecção: Financeiro não acessa
    if request.user.profile.is_financeiro:
        return HttpResponse("Acesso Negado ao Financeiro", status=403)
        
    # Agora busca na tabela ClienteProspect
    base_queryset = Prospeccao.objects.select_related('cliente', 'criado_por', 'iniciado_por', 'finalizado_por')
    
    filtro_representante = request.GET.get('representante_filtro', 'todos')
    data_inicial = request.GET.get('data_inicial')
    data_final = request.GET.get('data_final')
    
    if not request.user.profile.is_representante:
        if filtro_representante == 'minhas':
            base_queryset = base_queryset.filter(criado_por=request.user)
        elif filtro_representante != 'todos':
            base_queryset = base_queryset.filter(criado_por_id=filtro_representante)
    else:
        base_queryset = base_queryset.filter(criado_por=request.user)

    if data_inicial:
        base_queryset = base_queryset.filter(data_criacao__gte=data_inicial)
    if data_final:
        base_queryset = base_queryset.filter(data_criacao__lte=data_final)

    sort_novas = request.GET.get('sort_novas', 'desc')
    sort_neg = request.GET.get('sort_neg', 'desc')
    sort_fin = request.GET.get('sort_fin', 'desc')

    sort_novas_prefix = '' if sort_novas == 'asc' else '-'
    sort_neg_prefix = '' if sort_neg == 'asc' else '-'
    sort_fin_prefix = '' if sort_fin == 'asc' else '-'

    context = {
        'novas': base_queryset.filter(status='NOVA').order_by(f'{sort_novas_prefix}data_criacao'),
        'negociando': base_queryset.filter(status='NEGOCIANDO').order_by(f'{sort_neg_prefix}data_inicio_negociacao'),
        'finalizadas_fechado': base_queryset.filter(status='FECHADO').order_by(f'{sort_fin_prefix}data_finalizacao'),
        'finalizadas_desistencia': base_queryset.filter(status='DESISTENCIA').order_by(f'{sort_fin_prefix}data_finalizacao'),
        'finalizadas_perdida': base_queryset.filter(status='PERDIDA').order_by(f'{sort_fin_prefix}data_finalizacao'),
        'representantes': None,
        'filtro_selecionado': filtro_representante,
        'sort_novas_current': sort_novas,
        'sort_novas_next': 'desc' if sort_novas == 'asc' else 'asc',
        'sort_neg_current': sort_neg,
        'sort_neg_next': 'desc' if sort_neg == 'asc' else 'asc',
        'sort_fin_current': sort_fin,
        'sort_fin_next': 'desc' if sort_fin == 'asc' else 'asc',
    }
    
    if not request.user.profile.is_representante:
        # --- ALTERAÇÃO AQUI: Filtra dropdown de representantes ---
        context['representantes'] = User.objects.filter(profile__eh_representante=True).order_by('username')
        
    return render(request, 'app/prospeccao.html', context)

@login_required
def criar_prospeccao(request):
    if request.method == 'POST':
        form = ProspeccaoForm(request.POST, user=request.user)
        if form.is_valid():
            prospeccao = form.save(commit=False)
            prospeccao.criado_por = request.user
            prospeccao.save()
            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    else:
        form = ProspeccaoForm(user=request.user)
    return render(request, 'app/partials/_prospeccao_form_modal.html', {'form': form})

@login_required
def detalhe_prospeccao(request, pk):
    prospeccao = get_object_or_404(Prospeccao, pk=pk)
    if request.user.profile.is_representante and prospeccao.criado_por != request.user:
        return HttpResponse(status=403)
        
    context = {
        'prospeccao': prospeccao,
        'acao_form': AcaoProspeccaoForm()
    }
    return render(request, 'app/partials/_detalhe_prospeccao_modal.html', context)

@login_required
def iniciar_prospeccao(request, pk):
    prospeccao = get_object_or_404(Prospeccao, pk=pk)
    if request.method == 'POST':
        prospeccao.status = 'NEGOCIANDO'
        prospeccao.iniciado_por = request.user
        prospeccao.data_inicio_negociacao = timezone.now()
        prospeccao.save()
        return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    return HttpResponse(status=405)

@login_required
def gravar_acao_prospeccao(request, pk):
    prospeccao = get_object_or_404(Prospeccao, pk=pk)
    if request.method == 'POST':
        print(f"DEBUG PROSPECCAO - FILES: {request.FILES}")
        
        form = AcaoProspeccaoForm(request.POST, request.FILES)
        if form.is_valid():
            acao = form.save(commit=False)
            acao.prospeccao = prospeccao
            acao.registrado_por = request.user
            acao.save()
            return render(request, 'app/partials/_acoes_prospeccao_list.html', {'prospeccao': prospeccao})
        else:
            print(f"DEBUG PROSPECCAO - ERROS: {form.errors}")

    return HttpResponse(status=400)

@login_required
def finalizar_prospeccao(request, pk):
    prospeccao = get_object_or_404(Prospeccao, pk=pk)
    if request.method == 'POST':
        status_final = request.POST.get('status')
        
        if status_final in ['FECHADO', 'DESISTENCIA', 'PERDIDA']:
            prospeccao.status = status_final
            prospeccao.finalizado_por = request.user
            prospeccao.data_finalizacao = timezone.now()
            prospeccao.save()

            if status_final == 'FECHADO':
                descricao_acao = "Prospecção finalizada: Serviço Fechado."
            elif status_final == 'DESISTENCIA':
                descricao_acao = "Prospecção finalizada: Desistência do Cliente."
            else:
                descricao_acao = "Prospecção finalizada: Negociação Perdida."
            
            AcaoProspeccao.objects.create(
                prospeccao=prospeccao,
                descricao=descricao_acao,
                registrado_por=request.user
            )

            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
            
    return HttpResponse(status=400)
    
@login_required
def criar_cliente_prospeccao_modal(request):
    # ALTERAÇÃO: Usa o form de prospect
    form = ClienteProspectForm()
    return render(request, 'app/partials/_cliente_form_modal.html', {'form': form})

@login_required
def salvar_cliente_prospeccao(request):
    if request.method == 'POST':
        # ALTERAÇÃO: Usa o form de prospect
        form = ClienteProspectForm(request.POST)
        if form.is_valid():
            # Salva na tabela ClienteProspect
            cliente = form.save(commit=False)
            cliente.cadastrado_por = request.user
            cliente.save()
            
            # Retorna o ProspeccaoForm com o novo prospect selecionado
            prospeccao_form = ProspeccaoForm(user=request.user, initial={'cliente': cliente.id})
            return render(request, 'app/partials/_prospeccao_form_modal.html', {'form': prospeccao_form})
    return render(request, 'app/partials/_cliente_form_modal.html', {'form': form})

@login_required
def editar_prospeccao(request, pk):
    prospeccao = get_object_or_404(Prospeccao, pk=pk)

    if (not request.user.is_staff and prospeccao.criado_por != request.user) or prospeccao.status not in ['NOVA', 'NEGOCIANDO']:
        return HttpResponse(status=403)

    if request.method == 'POST':
        form = ProspeccaoEditForm(request.POST, instance=prospeccao)
        if form.is_valid():
            
            changes = []
            if form.has_changed():
                for field_name in form.changed_data:
                    old_value = form.initial.get(field_name)
                    new_value = form.cleaned_data.get(field_name)
                    field_label = Prospeccao._meta.get_field(field_name).verbose_name
                    changes.append(f'"{field_label}" alterado de "{old_value}" para "{new_value}".')
            
            updated_prospeccao = form.save()

            if 'valor_total' in form.cleaned_data and prospeccao.valor_total != updated_prospeccao.valor_total:
                 changes.append(f'"Valor Total Estimado" recalculado para "R$ {updated_prospeccao.valor_total}".')

            if changes:
                descricao_acao = "Dados da prospecção foram atualizados: " + " | ".join(changes)
                AcaoProspeccao.objects.create(
                    prospeccao=updated_prospeccao,
                    descricao=descricao_acao,
                    registrado_por=request.user
                )

            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    else:
        form = ProspeccaoEditForm(instance=prospeccao)
        
    return render(request, 'app/partials/_prospeccao_edit_form_modal.html', {'form': form, 'prospeccao': prospeccao})

# --- NOVA VIEW PARA O MODAL DE HISTÓRICO ---
@login_required
def servico_historico_modal(request, cliente_id, mes, ano):
    """
    Exibe o histórico de serviços de um cliente específico em um mês/ano.
    Chamado via HTMX.
    """
    cliente = get_object_or_404(Cliente, pk=cliente_id)
    
    if request.user.profile.is_representante and cliente.cadastrado_por != request.user:
         return HttpResponse(status=403)
         
    servicos = Servico.objects.filter(
        cliente_id=cliente_id,
        data_servico__year=ano, 
        data_servico__month=mes
    ).order_by('data_servico')
    
    if request.user.profile.is_representante:
        # Filtra serviços onde o cliente pertence ao usuário logado
        servicos = servicos.filter(cliente__cadastrado_por=request.user)

    context = {
        'cliente': cliente,
        'servicos': servicos,
        'mes': mes,
        'ano': ano,
        'nome_mes': calendar.month_name[mes].capitalize()
    }
    return render(request, 'app/partials/_servico_historico_modal.html', context)

# --- NOVAS VIEWS DE PROMOÇÃO (MIGRAÇÃO ASSISTIDA) ---

@login_required
def promover_prospect_modal(request, pk):
    """
    Abre um modal com o formulário de Cliente pré-preenchido com os dados do Prospect.
    CNPJ e dados de contato são travados para edição.
    """
    prospect = get_object_or_404(ClienteProspect, pk=pk)
    
    if request.user.profile.is_representante and prospect.cadastrado_por != request.user:
        return HttpResponse(status=403)

    initial_data = {
        'cnpj': prospect.cnpj,
        'razao_social': prospect.razao_social,
        'nome_contato': prospect.nome_contato,
        'telefone_contato': prospect.telefone_contato,
    }
    
    form = ClienteForm(initial=initial_data)
    
    # Trava os campos que não devem ser alterados
    form.fields['cnpj'].widget.attrs['readonly'] = True
    form.fields['nome_contato'].widget.attrs['readonly'] = True
    form.fields['telefone_contato'].widget.attrs['readonly'] = True
    
    return render(request, 'app/partials/_cliente_promocao_modal.html', {
        'form': form, 
        'prospect': prospect
    })

@login_required
def salvar_promocao_prospect(request, pk):
    """
    Processa o formulário de promoção: Cria o Cliente e deleta o Prospect.
    """
    prospect = get_object_or_404(ClienteProspect, pk=pk)
    
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                # 1. Salva o novo Cliente
                novo_cliente = form.save(commit=False)
                novo_cliente.cadastrado_por = prospect.cadastrado_por # Mantém o dono original
                novo_cliente.save()
                
                # 2. Deleta o Prospect antigo
                prospect.delete()
                
            return HttpResponse(status=204, headers={'HX-Refresh': 'true'})
    
    # Se houver erro no form, retorna o modal com erros (mantendo os campos travados)
    form.fields['cnpj'].widget.attrs['readonly'] = True
    form.fields['nome_contato'].widget.attrs['readonly'] = True
    form.fields['telefone_contato'].widget.attrs['readonly'] = True
    
    return render(request, 'app/partials/_cliente_promocao_modal.html', {
        'form': form, 
        'prospect': prospect
    })